package com.example.testpredict;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Button;

public class DetailsActivity extends AppCompatActivity {

    TextView tvResult;
    Button btnHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        tvResult = findViewById(R.id.tvResult);
        btnHome = findViewById(R.id.btnHome);

        String name = getIntent().getStringExtra("username");
        tvResult.setText("Welcome, " + name);

        btnHome.setOnClickListener(v -> finish());
    }
}
