package com.example.testpredict;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LoginActivity extends AppCompatActivity {

    EditText etName, etPassword;
    Button btnSubmit, btnBack;

    boolean hasError = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etName = findViewById(R.id.etName);
        etPassword = findViewById(R.id.etPassword);
        btnSubmit = findViewById(R.id.btnSubmit);
        btnBack = findViewById(R.id.btnBack);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
            String name = etName.getText().toString();
            String password = etPassword.getText().toString();

                if (name.isEmpty() && password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    etName.setError("Required");
                    etPassword.setError("Required");
                    return;
                }

                if (name.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Name cannot be empty", Toast.LENGTH_SHORT).show();
                    etName.setError("Required");
                    return;
                }

                if (password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Password cannot be empty", Toast.LENGTH_SHORT).show();
                    etPassword.setError("Required");
                    return;
                }

            Intent intent = new Intent(LoginActivity.this, DetailsActivity.class);
            intent.putExtra("username", name);
            intent.putExtra("password", password);
            startActivity(intent);
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                finish();
            }
        });
        }
    }
